package com.TKAGopal.Revision.SpringBoot.Project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RevisionSpringBootProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
