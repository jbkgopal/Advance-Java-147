import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class EmployeeController {

	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.addAnnotatedClass(Employee.class).configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session ss = sf.openSession();
		Transaction t = ss.beginTransaction();
		Employee ee = new Employee(102, "Java");
		ss.save(ee); // insert//add/save
		System.out.println("inserted......" + ee);

		ss.update(ee);
		System.out.println("updated......" + ee);

		ss.delete(ee);
		System.out.println("deleted......" + ee);
		t.commit();
		ss.close();
	}
}
